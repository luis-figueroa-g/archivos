from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route("/home")
def home():
    return render_template("home.html")

@app.route('/')
def index():
    return redirect(url_for('home'))


@app.route("/monitor")
def monitor():
    return render_template("monitor.html")  # Carga la plantilla para el monitor

@app.route("/help")
def help():
    return render_template("help.html")  # Carga la plantilla para el monitor

@app.route("/seguimiento")
def seguimiento():
    return render_template("seguimiento.html")  # Carga la plantilla para el monitor

@app.route("/perfil")
def perfil():
    return render_template("perfil.html")  # Carga la plantilla para el monitor




if __name__ == "__main__":
    app.run(debug=True)
